// SPDX-License-Identifier: GPL-3.0-or-later

package org.firehol.netdata.orchestrator.configuration;

public class TestConfiguration {
	public String testProperty = "defaultValue";
}
