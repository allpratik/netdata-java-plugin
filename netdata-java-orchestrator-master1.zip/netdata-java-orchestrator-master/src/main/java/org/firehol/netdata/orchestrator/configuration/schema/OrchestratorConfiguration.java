// SPDX-License-Identifier: GPL-3.0-or-later

package org.firehol.netdata.orchestrator.configuration.schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class OrchestratorConfiguration {
}
